
import java.util.Set;
import java.util.HashSet;
import edu.princeton.cs.algs4.SET;

public class BoggleSolver {

    private TrieSET dict;


    public BoggleSolver(String[] dict) {
        this.dict = new TrieSET();

        
        for (String word : dict) {
            this.dict.add(word);
        }

    }


    public Iterable<String> getAllValidWords(BoggleBoard board) {
        Set<String> valid_words = new HashSet<String>();
        for (int a = 0; a < board.rows(); a++) {
            for (int b = 0; b < board.cols(); b++) {
                boolean[][] visited = new boolean[board.rows()][board.cols()];
                solver(board, a, b, visited, "", valid_words);
            }
        }
        return valid_words;

    }

    private void solver(BoggleBoard board, int row, int col, boolean[][] visited, String pre, Set<String> set) {

        if (visited[row][col]) {
            return;
        }

        char letter = board.getLetter(row, col);
        String S = pre;

        if (letter == 'Q') {
            S = S + "QU";
        } else {
            S = S + letter;
        }
        if (!dict.hasPrefix(S)) {
            return;
        }
        if (S.length() > 2 && dict.contains(S)) {
            set.add(S);
        }
        visited[row][col] = true;

        for (int l = -1; l <= 1; l++) {
            for (int m = -1; m <= 1; m++) {
                if (l == 0 && m == 0) {
                    continue;
                }
                if ((row + l >= 0) && (row + l < board.rows() && (col + m >= 0) && (col + m < board.cols()))) {
                    solver(board, row + l, col + m, visited, S, set);
                }
            }
        }
        visited[row][col] = false;
    }

    public int scoreOf(String WORD) {

        if (dict.contains(WORD)) {

            switch (WORD.length()) {
            case 0:
            case 1:
            case 2:
                return 0;
            case 3:
            case 4:
                return 1;
            case 5:
                return 2;
            case 6:
                return 3;
            case 7:
                return 5;
            default:
                return 11;
            }
        } else {
            return 0;
        }

    }

    public static void main(String[] args) {

    }
}
